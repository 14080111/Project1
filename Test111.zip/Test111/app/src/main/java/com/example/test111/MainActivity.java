package com.example.test111;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    Button button1;
    RadioGroup rg;
    TextView text1;
    EditText editText1;
    Switch switch1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=(EditText)findViewById(R.id.et_mima);
        button1=(Button)findViewById(R.id.button33);
        rg = (RadioGroup) findViewById(R.id.rg);
        text1= (TextView)findViewById(R.id.text1);
        switch1=(Switch)findViewById(R.id.switch1);
        button1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                text1.setText("What's Up");
                text1.setText(editText1.getText().toString());
                System.out.println("ssss");
                Log.v("test", "chenggongtiaozhuan");
            }
        });
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {

                if(checkedId==R.id.radioButton1)
                {
                    text1.setText("1");
                }
                if(checkedId==R.id.radioButton2)
                {
                    text1.setText("2");
                }
                if(checkedId==R.id.radioButton3)
                {
                    text1.setText("3");
                }
            }
        });


        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    text1.setText("开关已开启");
                }else {
                    text1.setText("开关已关闭");
                }
            }
        });

    }
}
